const express = require('express');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const bodyParser = require('body-parser');
const { Sequelize, DataTypes } = require('sequelize');

// Database connection
const sequelize = new Sequelize('chattsystemlagring', 'root', 'Rovdjur321', {
  host: 'localhost',
  dialect: 'mysql',
});

// Message model
const Message = sequelize.define('Message', {
  username: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  message: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

// Parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// Parse application/json
app.use(bodyParser.json());

// Serve static files
app.use(express.static('public'));

// Handle root route
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// Handle new chat messages
io.on('connection', (socket) => {
  console.log('A user connected.');

  socket.on('chat message', async (data) => {
    try {
      const { username, message } = data;
      const newMessage = await Message.create({ username, message });
      io.emit('message created', {
        id: newMessage.id,
        username: newMessage.username,
        message: newMessage.message,
      });
    } catch (error) {
      console.error('Error saving message:', error);
    }
  });

  socket.on('delete message', async (messageId) => {
    try {
      const message = await Message.findByPk(messageId);
      if (!message) {
        console.error('Message not found');
        return;
      }

      await message.destroy();
      io.emit('delete message', messageId);
    } catch (error) {
      console.error('Error deleting message:', error);
    }
  });

  socket.on('disconnect', () => {
    console.log('A user disconnected.');
  });
});

// Sync the database and start the server
sequelize.sync()
  .then(() => {
    http.listen(3000, () => {
      console.log('Server running on port 3000');
      console.log('Chat app running at http://localhost:3000');
    });
  })
  .catch((error) => {
    console.error('Error syncing database:', error);
  });
